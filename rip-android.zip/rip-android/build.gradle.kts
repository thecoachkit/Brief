// Versioni scelte perché note per funzionare insieme (AGP 8.5 richiede Gradle 8.7+ e JDK 17).
plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
}
