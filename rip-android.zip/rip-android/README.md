# Brief rapido per coach — app Android per il brief vocale di fine sessione

A fine sessione leggi i tuoi appunti a voce (2–4 minuti): l'app trascrive **sul telefono**, riconosce i marker
("Consapevolezze emerse", "Cosa farà"…) e produce un PDF a 8 sezioni da salvare o condividere.
Niente cloud, niente API, niente LLM: Vosk (modello italiano piccolo) + PDF generato in memoria.

## Come ottenere l'APK gratis (GitHub Actions)

1. Crea un account GitHub e un repository **pubblico** (il piano gratuito compila gratis solo così; nel repository c'è solo codice).
2. Carica **tutto il contenuto di questa cartella** nel repository, ramo `main`, mantenendo le cartelle
   (inclusa `.github/workflows/build-apk.yml`). Da PC: "Add file → Upload files" e trascina le cartelle.
3. Vai su **Actions → Build APK → Run workflow**. La build scarica da sola il modello italiano (48 MB) e compila.
4. A fine build, nella pagina dell'esecuzione scarica l'artefatto **rip-apk** (uno zip), estrai `app-debug.apk`.
5. Sul telefono apri l'APK e consenti l'installazione da questa fonte quando Android lo chiede.

> Ogni build ha una firma di debug diversa: per installare una versione nuova **disinstalla prima la vecchia**
> (non perdi nulla, l'app non conserva dati).

### Alternativa: Android Studio
Scarica `vosk-model-small-it-0.22.zip` da alphacephei.com/vosk/models, decomprimi e copia il contenuto
(am, conf, graph, ivector…) in `app/src/main/assets/model-it/`. Apri la cartella con Android Studio e premi Run.

## Uso

1. Primo avvio: concedi il permesso del microfono; l'app copia il modello (qualche secondo, solo la prima volta).
2. **REGISTRA** → leggi gli appunti dicendo i marker ad alta voce → **STOP**.
3. Compare l'**anteprima**: un riquadro modificabile per ogni sezione (sempre tutte e 8). Correggi le parole sbagliate, aggiungi o togli punti
   (una riga = un punto elenco) e compila a mano le sezioni mancanti. Un avviso ⚠ segnala i marker non riconosciuti.
   Sezione lasciata vuota → "Da definire" nel PDF; "Obiettivo esplorato" vuoto → omessa.
4. **Salva PDF** (scegli dove; il PDF viene creato dal testo che c'è in quel momento nei riquadri; dopo il salvataggio testo e PDF in memoria vengono cancellati). Al termine appare la domanda **"Vuoi aprire subito il PDF?"**: scegli **Sì** per aprire il file appena salvato con un visualizzatore PDF del telefono, oppure **No** per restare nell’app. In alternativa usa **Condividi**.
   "Indietro" con un'anteprima aperta chiede conferma, per non perdere le correzioni.

Consigli: pronuncia i marker in modo chiaro; fai una breve pausa tra un punto e l'altro (ogni pausa = un punto elenco);
tieni l'app in primo piano (in background Android silenzia il microfono: l'app in quel caso chiude e genera il PDF con quanto registrato).

## Cosa fa con i dati

- Audio e testo restano in RAM: l'audio non viene mai conservato, il testo dell'anteprima resta finché non salvi o premi "Nuova registrazione". Il modello vocale sta nella memoria privata dell'app.
- Il PDF vive solo in RAM fino al salvataggio. "Condividi" crea una copia temporanea nella cache, cancellata alla successiva apertura/chiusura.
- Il PDF salvato da te nella posizione scelta è, ovviamente, un file del telefono.

## Struttura

| File | Ruolo |
|---|---|
| `MainActivity.kt` | schermata unica, Vosk `SpeechService` (trascrive mentre parli), salvataggio/condivisione |
| `SessionParser.kt` | marker → sezioni (stesse regole di `rip.py`) |
| `PdfBuilder.kt` | PDF A4 con l'API standard di Android |
| `.github/workflows/build-apk.yml` | compila l'APK su GitHub |

## Limiti noti

- Registrazione massima 10 minuti; solo telefoni a 64 bit (arm64-v8a).
- Il testo detto prima del primo marker viene scartato; un "cosa farà" detto dentro un contenuto apre una nuova sezione.
- Il modello piccolo sbaglia qualche parola (circa 17% di errori nei test pubblici di Vosk): i marker vanno pronunciati con chiarezza.

## Se qualcosa non va

- *"modello assente nell'app (assets/model-it)"*: la cartella del modello non è finita nell'APK (controlla il passo di download nel workflow).
- *"Duplicate class com.sun.jna"* in build: elimina la riga `net.java.dev.jna:jna:5.13.0@aar` in `app/build.gradle.kts`.
- *"Microfono non disponibile"*: controlla il permesso e che nessun'altra app stia registrando.
- *L'APK non si installa sopra la versione precedente*: disinstalla la vecchia e riprova.

## Stato della verifica

Scritto seguendo la demo ufficiale `vosk-android-demo` e la libreria `com.alphacephei:vosk-android:0.3.75`.
Le regex del parsing sono state verificate con test automatici (equivalente Java). **Il progetto non è stato compilato né provato su un telefono**:
il primo collaudo reale (compilazione, microfono, riconoscimento dei marker, PDF) è tutto da fare.
