package it.rip.riepilogo

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.TextView
import androidx.core.content.FileProvider
import org.json.JSONObject
import org.vosk.LibVosk
import org.vosk.LogLevel
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Una sola schermata: REGISTRA → (parli, leggendo gli appunti) → STOP → PDF pronto → Salva / Condividi.
 * Tutto offline: Vosk trascrive mentre parli; audio e testo restano in RAM e vengono scartati.
 */
class MainActivity : Activity(), RecognitionListener {

    private enum class State { LOADING, IDLE, RECORDING, PROCESSING, READY, ERROR }

    private companion object {
        const val MODEL_ASSET_DIR = "model-it"
        const val SAMPLE_RATE = 16000.0f
        const val MAX_SECONDS = 600
        const val MIN_SECONDS = 2
        const val REQ_AUDIO = 1
        const val REQ_SAVE = 2
        val RED: Int = Color.parseColor("#D32F2F")
        val GREEN: Int = Color.parseColor("#2E7D32")
        val GREY: Int = Color.parseColor("#4B5160")
        val BLUE: Int = Color.parseColor("#1565C0")
    }

    private var model: Model? = null
    private var recognizer: Recognizer? = null
    private var speech: SpeechService? = null

    private val segments = ArrayList<String>()
    private var pdf: ByteArray? = null
    private var pdfName = "riepilogo.pdf"
    private var state = State.LOADING
    private var startedAt = 0L
    private var extraNote = ""
    private val main = Handler(Looper.getMainLooper())

    private lateinit var btnMain: Button
    private lateinit var btnSave: Button
    private lateinit var btnShare: Button
    private lateinit var btnAgain: Button
    private lateinit var tvStatus: TextView
    private lateinit var tvLive: TextView
    private lateinit var tvNote: TextView

    private val ticker = object : Runnable {
        override fun run() {
            if (state != State.RECORDING) return
            val s = ((System.currentTimeMillis() - startedAt) / 1000).toInt()
            tvStatus.text = String.format(Locale.US, "%02d:%02d", s / 60, s % 60)
            if (s >= MAX_SECONDS) stopRecording() else main.postDelayed(this, 500)
        }
    }

    // ── ciclo di vita ────────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        btnMain = findViewById(R.id.btnMain)
        btnSave = findViewById(R.id.btnSave)
        btnShare = findViewById(R.id.btnShare)
        btnAgain = findViewById(R.id.btnAgain)
        tvStatus = findViewById(R.id.tvStatus)
        tvLive = findViewById(R.id.tvLive)
        tvNote = findViewById(R.id.tvNote)
        btnSave.setBackgroundColor(BLUE)

        btnMain.setOnClickListener {
            when (state) {
                State.IDLE, State.ERROR -> startRecording()
                State.RECORDING -> stopRecording()
                else -> Unit
            }
        }
        btnSave.setOnClickListener { savePdf() }
        btnShare.setOnClickListener { sharePdf() }
        btnAgain.setOnClickListener {
            wipeAll()
            setState(State.IDLE, "")
        }

        deleteShareDir() // eventuali residui di una sessione precedente
        loadModel()
    }

    override fun onStop() {
        super.onStop()
        // In background Android silenzia il microfono: meglio chiudere subito con quello che c'è.
        if (state == State.RECORDING) {
            extraNote = "Registrazione interrotta: l'app è andata in secondo piano. "
            stopRecording()
        }
    }

    override fun onDestroy() {
        state = State.IDLE // ignora eventuali risultati in arrivo
        releaseSpeech()
        deleteShareDir()
        try {
            model?.close()
        } catch (e: Exception) {
            // niente da fare in chiusura
        }
        model = null
        super.onDestroy()
    }

    // ── modello vocale ───────────────────────────────────────────────────────

    private fun loadModel() {
        setState(State.LOADING, "Carico il modello vocale…")
        Thread {
            try {
                val dir = prepareModelDir()
                LibVosk.setLogLevel(LogLevel.WARNINGS)
                val m = Model(dir.absolutePath)
                runOnUiThread {
                    model = m
                    setState(State.IDLE, "Pronto")
                }
            } catch (e: Throwable) {
                runOnUiThread { setState(State.ERROR, "Modello non caricato: ${e.message}") }
            }
        }.start()
    }

    /** Alla prima apertura copia il modello dagli asset nella memoria privata dell'app (poi lo riusa). */
    private fun prepareModelDir(): File {
        val target = File(filesDir, "model")
        val ok = File(filesDir, "model.ok")
        if (ok.exists() && target.isDirectory) return target
        if (assets.list(MODEL_ASSET_DIR).isNullOrEmpty()) {
            throw IllegalStateException("modello assente nell'app (assets/$MODEL_ASSET_DIR)")
        }
        target.deleteRecursively()
        copyAssets(MODEL_ASSET_DIR, target)
        ok.writeText("1")
        return target
    }

    private fun copyAssets(src: String, dst: File) {
        val names = assets.list(src) ?: emptyArray()
        if (names.isEmpty()) { // è un file
            dst.parentFile?.mkdirs()
            assets.open(src).use { input -> FileOutputStream(dst).use { out -> input.copyTo(out) } }
        } else {
            dst.mkdirs()
            for (n in names) copyAssets("$src/$n", File(dst, n))
        }
    }

    // ── registrazione ────────────────────────────────────────────────────────

    private fun startRecording() {
        val m = model
        if (m == null) {
            loadModel()
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQ_AUDIO)
            return
        }
        wipeAll()
        extraNote = ""
        try {
            val rec = Recognizer(m, SAMPLE_RATE)
            recognizer = rec
            val svc = SpeechService(rec, SAMPLE_RATE)
            speech = svc
            if (!svc.startListening(this)) throw IllegalStateException("il microfono non parte")
        } catch (e: Exception) {
            releaseSpeech()
            setState(State.ERROR, "Microfono non disponibile: ${e.message}")
            return
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        startedAt = System.currentTimeMillis()
        setState(State.RECORDING, "00:00")
        main.postDelayed(ticker, 500)
    }

    private fun stopRecording() {
        if (state != State.RECORDING) return
        setState(State.PROCESSING, "Elaboro…")
        val accepted = try {
            speech?.stop() ?: false // il risultato finale arriva in onFinalResult
        } catch (e: Exception) {
            false
        }
        if (!accepted) finishRecording()
    }

    private fun finishRecording() {
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        releaseSpeech()
        val elapsed = (System.currentTimeMillis() - startedAt) / 1000
        if (elapsed < MIN_SECONDS) {
            segments.clear()
            setState(State.ERROR, "Registrazione troppo breve.")
            return
        }
        if (segments.isEmpty()) {
            setState(State.ERROR, "Non ho sentito parlato. Controlla il microfono e riprova.")
            return
        }
        try {
            val parsed = SessionParser.parse(segments)
            val blocks = SessionParser.buildBlocks(parsed, segments)
            val now = Date()
            pdf = PdfBuilder.build(
                blocks,
                SimpleDateFormat("dd/MM/yyyy", Locale.ITALY).format(now),
                SimpleDateFormat("dd/MM/yyyy 'alle' HH:mm", Locale.ITALY).format(now)
            )
            pdfName = "riepilogo_" + SimpleDateFormat("ddMMyyyy_HHmm", Locale.ITALY).format(now) + ".pdf"
            val missing = SessionParser.missingTitles(parsed)
            val note = when {
                parsed.found.isEmpty() -> "Nessun marker riconosciuto: il PDF contiene la trascrizione grezza."
                missing.isNotEmpty() -> "⚠ Marker non riconosciuti: " + missing.joinToString(", ") + "."
                else -> "Tutte le sezioni rilevate ✓"
            }
            segments.clear() // il testo non serve più: resta solo il PDF in RAM
            setState(State.READY, "PDF pronto ✓", extraNote + note)
        } catch (e: Exception) {
            setState(State.ERROR, "Errore nella creazione del PDF: ${e.message}")
        }
    }

    private fun releaseSpeech() {
        main.removeCallbacks(ticker)
        try {
            speech?.cancel() // se ha già finito non fa nulla e non genera altri risultati
            speech?.shutdown()
        } catch (e: Exception) {
            // già fermo
        }
        try {
            recognizer?.close()
        } catch (e: Exception) {
            // già chiuso
        }
        speech = null
        recognizer = null
    }

    // ── callback di Vosk (arrivano sul thread principale) ───────────────────

    override fun onPartialResult(hypothesis: String?) {
        if (state != State.RECORDING) return
        val p = try {
            JSONObject(hypothesis ?: return).optString("partial", "")
        } catch (e: Exception) {
            ""
        }
        tvLive.text = if (p.length > 120) "…" + p.takeLast(120) else p
    }

    override fun onResult(hypothesis: String?) {
        if (state == State.RECORDING || state == State.PROCESSING) addText(hypothesis)
    }

    override fun onFinalResult(hypothesis: String?) {
        if (state != State.PROCESSING) return
        addText(hypothesis)
        finishRecording()
    }

    override fun onError(exception: Exception?) {
        if (state != State.RECORDING && state != State.PROCESSING) return
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        releaseSpeech()
        setState(State.ERROR, "Errore del microfono: ${exception?.message}")
    }

    override fun onTimeout() = Unit

    /** Un "risultato" di Vosk è un JSON {"text": "..."}: un segmento di parlato chiuso da una pausa. */
    private fun addText(json: String?) {
        val t = try {
            JSONObject(json ?: return).optString("text", "").trim()
        } catch (e: Exception) {
            ""
        }
        if (t.isNotEmpty()) segments.add(t)
    }

    // ── permessi, salvataggio, condivisione ─────────────────────────────────

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_AUDIO) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                setState(State.IDLE, "Permesso concesso: premi REGISTRA")
            } else {
                setState(State.ERROR, "Serve il permesso del microfono (Impostazioni → App → Riepilogo → Permessi).")
            }
        }
    }

    private fun savePdf() {
        if (pdf == null) return
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
            .addCategory(Intent.CATEGORY_OPENABLE)
            .setType("application/pdf")
            .putExtra(Intent.EXTRA_TITLE, pdfName)
        startActivityForResult(i, REQ_SAVE)
    }

    @Deprecated("API del framework, sufficiente per questa app")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_SAVE || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        val bytes = pdf ?: return
        try {
            contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
            wipeAll() // una tantum: salvato, la copia in memoria viene cancellata
            setState(State.IDLE, "Salvato. Copia cancellata dalla memoria.")
        } catch (e: Exception) {
            setState(State.READY, "Salvataggio non riuscito: ${e.message}", "")
        }
    }

    private fun sharePdf() {
        val bytes = pdf ?: return
        try {
            val dir = File(cacheDir, "share").apply { mkdirs() }
            val f = File(dir, pdfName)
            f.writeBytes(bytes)
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
            val send = Intent(Intent.ACTION_SEND)
                .setType("application/pdf")
                .putExtra(Intent.EXTRA_STREAM, uri)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(send, "Condividi il riepilogo"))
        } catch (e: Exception) {
            tvNote.text = "Condivisione non riuscita: ${e.message}"
        }
    }

    // ── pulizia e interfaccia ────────────────────────────────────────────────

    private fun wipeAll() {
        segments.clear()
        pdf = null
        deleteShareDir()
    }

    private fun deleteShareDir() {
        File(cacheDir, "share").deleteRecursively()
    }

    private fun setState(s: State, status: String, note: String = "") {
        state = s
        tvStatus.text = status
        tvNote.text = note
        if (s != State.RECORDING) tvLive.text = ""

        val ready = s == State.READY
        btnMain.visibility = if (ready) View.GONE else View.VISIBLE
        btnSave.visibility = if (ready) View.VISIBLE else View.GONE
        btnShare.visibility = if (ready) View.VISIBLE else View.GONE
        btnAgain.visibility = if (ready) View.VISIBLE else View.GONE

        btnMain.isEnabled = s == State.IDLE || s == State.RECORDING || s == State.ERROR
        when (s) {
            State.RECORDING -> {
                btnMain.text = "⏹ STOP"
                btnMain.setBackgroundColor(GREEN)
            }
            State.LOADING, State.PROCESSING -> {
                btnMain.text = if (s == State.LOADING) "Carico…" else "Elaboro…"
                btnMain.setBackgroundColor(GREY)
            }
            else -> {
                btnMain.text = "⏺ REGISTRA"
                btnMain.setBackgroundColor(RED)
            }
        }
    }
}
