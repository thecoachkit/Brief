package it.rip.riepilogo

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import java.io.ByteArrayOutputStream
import java.util.Locale

/** Genera il PDF in memoria con l'API standard di Android (nessuna libreria esterna). */
object PdfBuilder {
    private const val PAGE_W = 595 // A4 a 72 dpi
    private const val PAGE_H = 842
    private const val MARGIN = 56f

    private fun paint(size: Float, bold: Boolean, c: Int): TextPaint =
        TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = size
            typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            color = c
        }

    private fun layout(text: String, p: TextPaint, width: Int, align: Layout.Alignment): StaticLayout =
        StaticLayout.Builder.obtain(text, 0, text.length, p, width)
            .setAlignment(align)
            .setLineSpacing(0f, 1.2f)
            .build()

    /** Tiene traccia di pagina corrente e posizione verticale; va a capo pagina quando serve. */
    private class Writer(val doc: PdfDocument) {
        var page: PdfDocument.Page? = null
        var canvas: Canvas? = null
        var pageNo = 0
        var y = MARGIN

        fun newPage() {
            page?.let { doc.finishPage(it) }
            pageNo++
            val pg = doc.startPage(PdfDocument.PageInfo.Builder(PAGE_W, PAGE_H, pageNo).create())
            page = pg
            canvas = pg.canvas
            y = MARGIN
        }

        fun ensure(h: Float) {
            if (page == null || y + h > PAGE_H - MARGIN) newPage()
        }

        fun draw(l: StaticLayout, x: Float, advance: Boolean = true) {
            ensure(l.height.toFloat())
            val c = canvas!!
            c.save()
            c.translate(x, y)
            l.draw(c)
            c.restore()
            if (advance) y += l.height
        }

        fun space(h: Float) {
            y += h
        }

        fun rule(p: Paint) {
            ensure(8f)
            canvas!!.drawLine(MARGIN, y, PAGE_W - MARGIN, y, p)
            y += 1f
        }

        fun finish() {
            page?.let { doc.finishPage(it) }
            page = null
        }
    }

    fun build(blocks: List<SessionParser.Block>, date: String, generatedAt: String): ByteArray {
        val doc = PdfDocument()
        val w = Writer(doc)
        val width = (PAGE_W - 2 * MARGIN).toInt()
        val left = Layout.Alignment.ALIGN_NORMAL

        val titleP = paint(20f, true, Color.rgb(20, 20, 20))
        val metaP = paint(11f, false, Color.rgb(90, 90, 90))
        val headP = paint(12f, true, Color.rgb(30, 30, 80))
        val bodyP = paint(11f, false, Color.rgb(40, 40, 40))
        val footP = paint(9f, false, Color.rgb(120, 120, 120))
        val rulePaint = Paint().apply {
            color = Color.rgb(180, 180, 180)
            strokeWidth = 1f
        }

        w.newPage()
        w.draw(layout("Riepilogo Sessione di Coaching", titleP, width, left), MARGIN)
        w.space(4f)
        w.draw(layout("Data: $date", metaP, width, left), MARGIN)
        w.space(8f)
        w.rule(rulePaint)
        w.space(18f)

        for (b in blocks) {
            val head = layout(b.title.uppercase(Locale.ITALY), headP, width, left)
            w.ensure(head.height + 48f) // niente titolo orfano a fondo pagina
            w.draw(head, MARGIN)
            w.space(6f)
            for (line in b.lines) {
                if (b.bullets) {
                    val l = layout(line, bodyP, width - 22, left)
                    w.ensure(l.height.toFloat())
                    w.draw(layout("•", bodyP, 14, left), MARGIN + 8f, advance = false)
                    w.draw(l, MARGIN + 22f)
                    w.space(5f)
                } else {
                    w.draw(layout(line, bodyP, width, left), MARGIN)
                    w.space(5f)
                }
            }
            w.space(12f)
        }

        w.space(4f)
        w.rule(rulePaint)
        w.space(8f)
        w.draw(layout("Generato il $generatedAt", footP, width, Layout.Alignment.ALIGN_CENTER), MARGIN)
        w.finish()

        val out = ByteArrayOutputStream()
        doc.writeTo(out)
        doc.close()
        return out.toByteArray()
    }
}
