package it.rip.riepilogo

/**
 * Dal testo trascritto alle sezioni del riepilogo.
 * Porta in Kotlin la logica di rip.py: stessi marker, stesse regole.
 *
 * Vosk non produce punteggiatura: ogni "segmento" (una pausa del parlato) arriva come
 * stringa a parte. I segmenti vengono uniti con "\n" così i marker possono comparire
 * anche a cavallo di due segmenti e, nelle sezioni a elenco, ogni segmento = un punto.
 */
object SessionParser {

    enum class Key(val title: String, val optional: Boolean, val bullets: Boolean) {
        OBIETTIVO_ESPLORATO("Obiettivo esplorato", true, false),
        CONSAPEVOLEZZE("Consapevolezze emerse", false, true),
        OBIETTIVO("Obiettivo di sessione / di percorso", false, false),
        CHI_SARA("Chi sarà ad obiettivo raggiunto", false, false),
        COME_SI_SENTIRA("Come si sentirà ad obiettivo raggiunto", false, false),
        COSA_STA_FACENDO("Cosa sta facendo", false, true),
        COSA_PUO_FARE("Cosa può fare", false, true),
        COSA_FARA("Cosa farà", false, true)
    }

    class Parsed(val sections: Map<Key, List<String>>, val found: Set<Key>)
    class Block(val title: String, val bullets: Boolean, val lines: List<String>)

    // Confini di parola espliciti (valgono anche per le lettere accentate).
    private const val BEFORE = """(?<![\p{L}\p{N}_])"""
    private const val AFTER = """(?![\p{L}\p{N}_])"""
    private const val AOR = """(?:\s+ad\s+obiettivo\s+raggiunto)?"""
    private const val PUNCT = """(?:\s*[:\-–—])?"""

    private fun rx(pattern: String): Regex =
        Regex(BEFORE + "(?:" + pattern + ")" + AFTER + PUNCT, RegexOption.IGNORE_CASE)

    // Tolleranti: accenti persi (sarà/sara), "emerse" facoltativo, "e di percorso", ecc.
    private val markers: List<Pair<Key, Regex>> = listOf(
        Key.OBIETTIVO_ESPLORATO to rx("""obiettivo\s+esplorato"""),
        Key.CONSAPEVOLEZZE to rx("""consapevolezze(?:\s+emerse)?"""),
        Key.OBIETTIVO to rx(
            """obiettivo\s+di\s+(?:sessione|percorso)""" +
                """(?:\s*(?:/|e|o)?\s*di\s+(?:sessione|percorso))?"""
        ),
        Key.CHI_SARA to rx("""chi\s+sar[àa]""" + AOR),
        Key.COME_SI_SENTIRA to rx("""come\s+si\s+sentir[àa]""" + AOR),
        Key.COSA_STA_FACENDO to rx("""cosa\s+sta\s+facendo"""),
        Key.COSA_PUO_FARE to rx("""cosa\s+pu[òo]\s+fare"""),
        Key.COSA_FARA to rx("""cosa\s+far[àa]""")
    )

    private val trimPunct = Regex("""^[\s,.:;\-–—]+|[\s,;]+$""")

    private class Hit(val start: Int, val end: Int, val key: Key)

    /** Ogni marker apre una sezione che dura fino al marker successivo. Il testo prima del primo marker si scarta. */
    fun parse(segments: List<String>): Parsed {
        val text = segments.map { it.trim() }.filter { it.isNotEmpty() }.joinToString("\n")

        val hits = ArrayList<Hit>()
        for ((key, regex) in markers) {
            for (m in regex.findAll(text)) hits.add(Hit(m.range.first, m.range.last + 1, key))
        }
        hits.sortWith(compareBy<Hit> { it.start }.thenBy { it.end })

        val clean = ArrayList<Hit>() // scarta i match sovrapposti
        for (h in hits) {
            if (clean.isNotEmpty() && h.start < clean.last().end) continue
            clean.add(h)
        }

        val sections = Key.values().associateWith { ArrayList<String>() }
        val found = LinkedHashSet<Key>()
        for ((i, h) in clean.withIndex()) {
            found.add(h.key)
            val nextStart = if (i + 1 < clean.size) clean[i + 1].start else text.length
            for (piece in text.substring(h.end, nextStart).split("\n")) {
                val p = trimPunct.replace(piece, "")
                if (p.isNotEmpty()) sections.getValue(h.key).add(p) // marker ripetuto: si accoda
            }
        }
        return Parsed(sections, found)
    }

    fun missingTitles(parsed: Parsed): List<String> =
        Key.values().filter { it !in parsed.found && !it.optional }.map { it.title }

    private fun cap(s: String): String = s.replaceFirstChar { it.uppercase() }

    private fun sentence(s: String): String {
        val t = cap(s.trim())
        return if (t.isNotEmpty() && t.last() in ".!?") t else "$t."
    }

    fun buildBlocks(parsed: Parsed, segments: List<String>): List<Block> {
        if (parsed.found.isEmpty()) {
            return listOf(
                Block(
                    "Trascrizione (nessun marker riconosciuto)", true,
                    segments.filter { it.isNotBlank() }.map { cap(it.trim()) }
                )
            )
        }
        val blocks = ArrayList<Block>()
        for (key in Key.values()) {
            val lines = parsed.sections.getValue(key)
            if (key.optional && lines.isEmpty()) continue // "Obiettivo esplorato" assente: omessa
            when {
                lines.isEmpty() -> blocks.add(Block(key.title, false, listOf("Da definire")))
                key.bullets -> blocks.add(Block(key.title, true, lines.map { cap(it) }))
                else -> blocks.add(Block(key.title, false, listOf(sentence(lines.joinToString(" ")))))
            }
        }
        return blocks
    }
}
