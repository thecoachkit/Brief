plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "it.rip.riepilogo"
    compileSdk = 34

    defaultConfig {
        applicationId = "it.rip.riepilogo"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "0.1"
        // Solo telefoni a 64 bit (quasi tutti quelli recenti): APK molto più leggero.
        ndk { abiFilters += listOf("arm64-v8a") }
    }

    buildTypes {
        release { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    // Riconoscimento vocale offline (Apache 2.0). Versione 0.3.75: supporta anche i telefoni con pagine da 16 KB.
    implementation("com.alphacephei:vosk-android:0.3.75")
    // JNA in formato aar, come nella demo ufficiale. Se la build segnala "Duplicate class com.sun.jna", elimina questa riga.
    implementation("net.java.dev.jna:jna:5.13.0@aar")
    // Serve solo per FileProvider (condivisione del PDF).
    implementation("androidx.core:core:1.13.1")
}
