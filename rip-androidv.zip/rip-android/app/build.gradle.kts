plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "it.rip.riepilogo"
    compileSdk = 34

    defaultConfig {
        applicationId = "it.rip.riepilogo"
        minSdk = 24
        targetSdk = 34
        versionCode = 4
        versionName = "0.4"
        // Solo telefoni a 64 bit (quasi tutti quelli recenti): APK molto più leggero.
        ndk { abiFilters += listOf("arm64-v8a") }
    }

    buildTypes {
        release { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

// Il font Geologica (SIL Open Font License 1.1) è scaricato automaticamente
// dalla raccolta ufficiale Google Fonts in occasione della compilazione.
// È così incluso negli asset dell'APK, senza installazioni o copie manuali.
val prepareGeologica by tasks.registering {
    group = "branding"
    description = "Include Geologica e la sua licenza negli asset Android"
    doLast {
        val fontsDir = file("src/main/assets/fonts").apply { mkdirs() }
        val sources = mapOf(
            "geologica.ttf" to "https://raw.githubusercontent.com/google/fonts/main/ofl/geologica/Geologica%5BCRSV%2CSHRP%2Cslnt%2Cwght%5D.ttf",
            "OFL.txt" to "https://raw.githubusercontent.com/google/fonts/main/ofl/geologica/OFL.txt"
        )
        sources.forEach { (name, url) ->
            val destination = fontsDir.resolve(name)
            if (!destination.isFile || destination.length() < 100L) {
                val temporary = fontsDir.resolve("$name.download")
                try {
                    java.net.URI(url).toURL().openStream().use { stream ->
                        temporary.outputStream().use { output -> stream.copyTo(output) }
                    }
                    check(temporary.length() > 100L) { "Download del font non valido: $name" }
                    if (name.endsWith(".ttf")) {
                        check(temporary.inputStream().use { input ->
                            val bytes = ByteArray(4)
                            input.read(bytes) == 4 && bytes.contentEquals(byteArrayOf(0, 1, 0, 0))
                        }) { "Il file Geologica scaricato non è un TrueType valido" }
                    }
                    temporary.renameTo(destination).also { check(it) { "Impossibile salvare $name" } }
                } finally {
                    temporary.delete()
                }
            }
        }
    }
}

tasks.configureEach {
    if (name.startsWith("merge") && name.endsWith("Assets")) {
        dependsOn(prepareGeologica)
    }
}

dependencies {
    // Riconoscimento vocale offline (Apache 2.0). Versione 0.3.75: supporta anche i telefoni con pagine da 16 KB.
    implementation("com.alphacephei:vosk-android:0.3.75")
    // JNA in formato aar, come nella demo ufficiale. Se la build segnala "Duplicate class com.sun.jna", elimina questa riga.
    implementation("net.java.dev.jna:jna:5.13.0@aar")
    // Serve solo per FileProvider (condivisione del PDF).
    implementation("androidx.core:core:1.13.1")
}
