Il carattere Geologica viene scaricato automaticamente da Google Fonts
quando si compila il progetto Android. Non occorre scaricare file manualmente.

Il font e la licenza OFL.txt sono aggiunti dal task Gradle prepareGeologica.
Per la prima compilazione è necessaria la connessione Internet, come per
il download delle altre dipendenze del progetto. Le successive usano la copia locale.
