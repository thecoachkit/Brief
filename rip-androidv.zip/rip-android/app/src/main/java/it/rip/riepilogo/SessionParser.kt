package it.rip.riepilogo

import java.text.Normalizer
import java.util.Locale

/**
 * Dal testo trascritto alle sezioni del brief.
 * Porta in Kotlin la logica di rip.py, con in più il riconoscimento "per somiglianza" dei marker.
 *
 * Vosk non produce punteggiatura: ogni "segmento" (una pausa del parlato) arriva come
 * stringa a parte. I segmenti vengono uniti con "\n" così i marker possono comparire
 * anche a cavallo di due segmenti e, nelle sezioni a elenco, ogni segmento = un punto.
 */
object SessionParser {

    enum class Key(val title: String, val optional: Boolean, val bullets: Boolean) {
        OBIETTIVO_ESPLORATO("Obiettivo esplorato", true, false),
        CONSAPEVOLEZZE("Consapevolezze emerse", false, true),
        OBIETTIVO("Obiettivo di sessione / di percorso", false, false),
        CHI_SARA("Chi sarà ad obiettivo raggiunto", false, false),
        COME_SI_SENTIRA("Come si sentirà ad obiettivo raggiunto", false, false),
        COSA_STA_FACENDO("Cosa sta facendo", false, true),
        COSA_PUO_FARE("Cosa può fare", false, true),
        COSA_FARA("Cosa farà", false, true)
    }

    /**
     * found    = marker riconosciuti (con le regex o per somiglianza)
     * fuzzy    = quelli tra i found riconosciuti solo per somiglianza (da ricontrollare)
     * inferred = sezioni il cui marker non è stato sentito ma a cui ho assegnato il testo iniziale
     */
    class Parsed(
        val sections: Map<Key, List<String>>,
        val found: Set<Key>,
        val fuzzy: Set<Key> = emptySet(),
        val inferred: Set<Key> = emptySet()
    )

    class Block(val title: String, val bullets: Boolean, val lines: List<String>, val optional: Boolean = false)

    // Confini di parola espliciti (valgono anche per le lettere accentate).
    private const val BEFORE = """(?<![\p{L}\p{N}_])"""
    private const val AFTER = """(?![\p{L}\p{N}_])"""
    private const val AOR = """(?:\s+ad\s+obiettivo\s+raggiunto)?"""
    private const val PUNCT = """(?:\s*[:\-–—])?"""

    private fun rx(pattern: String): Regex =
        Regex(BEFORE + "(?:" + pattern + ")" + AFTER + PUNCT, RegexOption.IGNORE_CASE)

    // Tolleranti: accenti persi (sarà/sara), singolare/plurale, parola spezzata ("con sapevolezze"), ecc.
    private val markers: List<Pair<Key, Regex>> = listOf(
        Key.OBIETTIVO_ESPLORATO to rx("""obiettivo\s+esplorato"""),
        Key.CONSAPEVOLEZZE to rx("""con\s*sapevolezz[ae](?:\s+emers[eao])?"""),
        Key.OBIETTIVO to rx(
            """obiettivo\s+di\s+(?:sessione|percorso)""" +
                """(?:\s*(?:/|e|o)?\s*di\s+(?:sessione|percorso))?"""
        ),
        Key.CHI_SARA to rx("""chi\s+sar[àa]""" + AOR),
        Key.COME_SI_SENTIRA to rx("""come\s+si\s+sentir[àa]""" + AOR),
        Key.COSA_STA_FACENDO to rx("""cosa\s+sta\s+facendo"""),
        Key.COSA_PUO_FARE to rx("""cosa\s+pu[òo]\s+fare"""),
        Key.COSA_FARA to rx("""cosa\s+far[àa]""")
    )

    // Frasi (senza accenti) cercate "per somiglianza" solo per i marker che le regex non hanno trovato.
    private val fuzzyPhrases: Map<Key, List<String>> = mapOf(
        Key.OBIETTIVO_ESPLORATO to listOf("obiettivo esplorato"),
        Key.CONSAPEVOLEZZE to listOf("consapevolezze emerse", "consapevolezze"),
        Key.OBIETTIVO to listOf("obiettivo di sessione", "obiettivo di percorso"),
        Key.CHI_SARA to listOf("chi sara ad obiettivo raggiunto", "chi sara"),
        Key.COME_SI_SENTIRA to listOf("come si sentira ad obiettivo raggiunto", "come si sentira"),
        Key.COSA_STA_FACENDO to listOf("cosa sta facendo"),
        Key.COSA_PUO_FARE to listOf("cosa puo fare"),
        Key.COSA_FARA to listOf("cosa fara")
    )

    private val trimPunct = Regex("""^[\s,.:;\-–—]+|[\s,;]+$""")
    private val nonSpace = Regex("""\S+""")
    private val accents = Regex("""\p{M}+""")

    private class Hit(val start: Int, val end: Int, val key: Key)
    private class Token(val start: Int, val end: Int, val norm: String)

    private fun norm(s: String): String =
        accents.replace(Normalizer.normalize(s.lowercase(Locale.ITALY), Normalizer.Form.NFD), "")

    /** Distanza di Levenshtein (numero minimo di inserimenti/cancellazioni/sostituzioni). */
    private fun lev(a: String, b: String): Int {
        if (a == b) return 0
        var prev = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            val cur = IntArray(b.length + 1)
            cur[0] = i
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost)
            }
            prev = cur
        }
        return prev[b.length]
    }

    /**
     * Cerca nel testo le parole che somigliano di più al marker (confronto senza spazi né accenti,
     * così "con sapevo lezze emerse" o "consapevolezza emersa" vanno bene). Più parole vicine alla frase
     * intera possono contare come marker. Ritorna null se nulla somiglia abbastanza.
     */
    private fun fuzzyFind(text: String, key: Key, taken: List<Hit>): Hit? {
        val tokens = nonSpace.findAll(text).map { Token(it.range.first, it.range.last + 1, norm(it.value)) }.toList()
        var best: Hit? = null
        var bestScore = 0.0
        var bestLen = 0
        for (phrase in fuzzyPhrases.getValue(key)) {
            val target = phrase.replace(" ", "")
            val words = phrase.split(" ").size
            val threshold = when {
                target.length >= 14 -> 0.72
                target.length >= 9 -> 0.82
                else -> 0.90
            }
            val minW = maxOf(1, words - 1)
            val maxW = words + 3
            for (i in tokens.indices) {
                val sb = StringBuilder()
                for (w in 1..maxW) {
                    val j = i + w - 1
                    if (j >= tokens.size) break
                    sb.append(tokens[j].norm)
                    if (w < minW) continue
                    if (sb.length > target.length * 2) break
                    val d = lev(sb.toString(), target)
                    val score = 1.0 - d.toDouble() / maxOf(sb.length, target.length)
                    if (score < threshold) continue
                    val start = tokens[i].start
                    val end = tokens[j].end
                    if (taken.any { start < it.end && end > it.start }) continue
                    val better = score > bestScore + 1e-9 ||
                        (Math.abs(score - bestScore) <= 1e-9 && target.length > bestLen)
                    if (better) {
                        best = Hit(start, end, key)
                        bestScore = score
                        bestLen = target.length
                    }
                }
            }
        }
        return best
    }

    /**
     * Dopo "consapevolezze" Vosk a volte sente male anche "emerse" ("emerge", "emersi", "e merse"…):
     * quella parola fa parte del marker e va tolta dal testo, altrimenti resta come punto elenco spurio.
     */
    private fun extendTail(text: String, h: Hit, limit: Int): Hit {
        val toks = nonSpace.findAll(text, h.end)
            .map { Token(it.range.first, it.range.last + 1, norm(it.value)) }
            .take(2)
            .toList()
        if (toks.isEmpty() || toks[0].end > limit) return h
        if (text.substring(h.end, toks[0].start).contains('\n')) return h
        if (toks.size == 2 && toks[1].end <= limit &&
            !text.substring(toks[0].end, toks[1].start).contains('\n') &&
            lev(toks[0].norm + toks[1].norm, "emerse") <= 1
        ) return Hit(h.start, toks[1].end, h.key)
        if (lev(toks[0].norm, "emerse") <= 1) return Hit(h.start, toks[0].end, h.key)
        return h
    }

    /** Ogni marker apre una sezione che dura fino al marker successivo. */
    fun parse(segments: List<String>): Parsed {
        val text = segments.map { it.trim() }.filter { it.isNotEmpty() }.joinToString("\n")

        val hits = ArrayList<Hit>()
        for ((key, regex) in markers) {
            for (m in regex.findAll(text)) hits.add(Hit(m.range.first, m.range.last + 1, key))
        }
        hits.sortWith(compareBy<Hit> { it.start }.thenBy { it.end })

        val clean = ArrayList<Hit>() // scarta i match sovrapposti
        for (h in hits) {
            if (clean.isNotEmpty() && h.start < clean.last().end) continue
            clean.add(h)
        }

        // Marker non trovati con le regex: li cerco per somiglianza (parola sentita male da Vosk).
        val fuzzy = LinkedHashSet<Key>()
        val have = HashSet<Key>()
        for (h in clean) have.add(h.key)
        for (key in Key.values()) {
            if (key in have) continue
            val h = fuzzyFind(text, key, clean) ?: continue
            clean.add(h)
            have.add(key)
            fuzzy.add(key)
        }
        clean.sortBy { it.start }
        for (i in clean.indices) {
            if (clean[i].key == Key.CONSAPEVOLEZZE) {
                val limit = if (i + 1 < clean.size) clean[i + 1].start else text.length
                clean[i] = extendTail(text, clean[i], limit)
            }
        }

        val sections = Key.values().associateWith { ArrayList<String>() }
        val found = LinkedHashSet<Key>()
        for ((i, h) in clean.withIndex()) {
            found.add(h.key)
            val nextStart = if (i + 1 < clean.size) clean[i + 1].start else text.length
            for (piece in text.substring(h.end, nextStart).split("\n")) {
                val p = trimPunct.replace(piece, "")
                if (p.isNotEmpty()) sections.getValue(h.key).add(p) // marker ripetuto: si accoda
            }
        }

        // "Consapevolezze emerse" è la prima sezione: se il suo marker non è stato sentito ma il primo
        // marker riconosciuto viene dopo, il testo iniziale è quasi certamente suo (non va perso).
        val inferred = LinkedHashSet<Key>()
        if (clean.isNotEmpty() && Key.CONSAPEVOLEZZE !in found && clean[0].key.ordinal > Key.CONSAPEVOLEZZE.ordinal) {
            for (piece in text.substring(0, clean[0].start).split("\n")) {
                val p = trimPunct.replace(piece, "")
                if (p.isNotEmpty()) sections.getValue(Key.CONSAPEVOLEZZE).add(p)
            }
            if (sections.getValue(Key.CONSAPEVOLEZZE).isNotEmpty()) inferred.add(Key.CONSAPEVOLEZZE)
        }
        return Parsed(sections, found, fuzzy, inferred)
    }

    fun missingTitles(parsed: Parsed): List<String> =
        Key.values()
            .filter { it !in parsed.found && it !in parsed.inferred && !it.optional }
            .map { it.title }

    /** Messaggio per l'utente sull'esito del riconoscimento dei marker. */
    fun describe(parsed: Parsed): String {
        if (parsed.found.isEmpty()) return "Nessun marker riconosciuto: qui sotto c'è la trascrizione grezza."
        val parts = ArrayList<String>()
        val missing = missingTitles(parsed)
        if (missing.isNotEmpty()) parts.add("⚠ Marker non riconosciuti: " + missing.joinToString(", ") + ".")
        if (parsed.inferred.isNotEmpty()) {
            parts.add(
                "⚠ " + parsed.inferred.joinToString(", ") { it.title } +
                    ": marker non sentito, ho assegnato il testo iniziale. Controlla."
            )
        }
        if (parsed.fuzzy.isNotEmpty()) {
            parts.add(
                "Marker riconosciuti per somiglianza: " + parsed.fuzzy.joinToString(", ") { it.title } +
                    ". Controlla."
            )
        }
        return if (parts.isEmpty()) "Tutte le sezioni rilevate ✓" else parts.joinToString(" ")
    }

    private fun cap(s: String): String = s.replaceFirstChar { it.uppercase() }

    private fun sentence(s: String): String {
        val t = cap(s.trim())
        return if (t.isNotEmpty() && t.last() in ".!?") t else "$t."
    }

    /** Bozza per l'anteprima: sempre tutte le 8 sezioni (vuote se il marker non è stato detto), così si possono compilare a mano. */
    fun draftBlocks(parsed: Parsed, segments: List<String>): List<Block> {
        if (parsed.found.isEmpty()) {
            return listOf(
                Block(
                    "Trascrizione (nessun marker riconosciuto)", true,
                    segments.filter { it.isNotBlank() }.map { cap(it.trim()) }
                )
            )
        }
        return Key.values().map { key ->
            val lines = parsed.sections.getValue(key)
            when {
                lines.isEmpty() -> Block(key.title, key.bullets, emptyList(), key.optional)
                key.bullets -> Block(key.title, true, lines.map { cap(it) }, key.optional)
                else -> Block(key.title, false, listOf(sentence(lines.joinToString(" "))), key.optional)
            }
        }
    }

    /**
     * Dal testo (eventualmente corretto a mano) ai blocchi del PDF.
     * Sezione vuota → "Da definire"; sezione facoltativa vuota → omessa.
     */
    fun finalBlocks(edited: List<Block>): List<Block> {
        val out = ArrayList<Block>()
        for (b in edited) {
            val lines = b.lines.map { it.trim() }.filter { it.isNotEmpty() }
            when {
                lines.isNotEmpty() -> out.add(Block(b.title, b.bullets, lines, b.optional))
                b.optional -> Unit
                else -> out.add(Block(b.title, false, listOf("Da definire")))
            }
        }
        return out
    }
}
