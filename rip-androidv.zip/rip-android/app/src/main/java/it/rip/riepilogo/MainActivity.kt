package it.rip.riepilogo

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import org.json.JSONObject
import org.vosk.LibVosk
import org.vosk.LogLevel
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Una sola schermata: REGISTRA → (parli, leggendo gli appunti) → STOP → anteprima modificabile
 * → Salva / Condividi. Tutto offline: Vosk trascrive mentre parli; audio e testo restano in RAM.
 */
class MainActivity : Activity(), RecognitionListener {

    private enum class State { LOADING, IDLE, RECORDING, PROCESSING, READY, ERROR }

    private companion object {
        const val MODEL_ASSET_DIR = "model-it"
        const val SAMPLE_RATE = 16000.0f
        const val MAX_SECONDS = 600
        const val MIN_SECONDS = 2
        const val REQ_AUDIO = 1
        const val REQ_SAVE = 2
    }

    /** Un riquadro di testo modificabile dell'anteprima, con la sezione a cui appartiene. */
    private class Editor(val block: SessionParser.Block, val edit: EditText)

    private var model: Model? = null
    private var recognizer: Recognizer? = null
    private var speech: SpeechService? = null

    private val segments = ArrayList<String>()
    private val editors = ArrayList<Editor>()
    private var pdf: ByteArray? = null
    private var pdfName = "riepilogo.pdf"
    private var state = State.LOADING
    private var startedAt = 0L
    private var extraNote = ""
    private var rawText = ""
    private var lastBack = 0L
    private val main = Handler(Looper.getMainLooper())

    private lateinit var btnMain: Button
    private lateinit var btnSave: Button
    private lateinit var btnShare: Button
    private lateinit var btnAgain: Button
    private lateinit var btnRaw: Button
    private lateinit var tvRaw: TextView
    private lateinit var tvStatus: TextView
    private lateinit var tvLive: TextView
    private lateinit var tvNote: TextView
    private lateinit var llPreview: LinearLayout

    private val textColor: Int by lazy { getColor(R.color.app_text) }

    private val ticker = object : Runnable {
        override fun run() {
            if (state != State.RECORDING) return
            val s = ((System.currentTimeMillis() - startedAt) / 1000).toInt()
            tvStatus.text = String.format(Locale.US, "%02d:%02d", s / 60, s % 60)
            if (s >= MAX_SECONDS) stopRecording() else main.postDelayed(this, 500)
        }
    }

    // ── ciclo di vita ────────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        btnMain = findViewById(R.id.btnMain)
        btnSave = findViewById(R.id.btnSave)
        btnShare = findViewById(R.id.btnShare)
        btnAgain = findViewById(R.id.btnAgain)
        btnRaw = findViewById(R.id.btnRaw)
        tvRaw = findViewById(R.id.tvRaw)
        tvStatus = findViewById(R.id.tvStatus)
        tvLive = findViewById(R.id.tvLive)
        tvNote = findViewById(R.id.tvNote)
        llPreview = findViewById(R.id.llPreview)

        btnMain.setOnClickListener {
            when (state) {
                State.IDLE, State.ERROR -> startRecording()
                State.RECORDING -> stopRecording()
                else -> Unit
            }
        }
        btnSave.setOnClickListener { savePdf() }
        btnShare.setOnClickListener { sharePdf() }
        btnRaw.setOnClickListener { toggleRaw() }
        btnAgain.setOnClickListener {
            wipeAll()
            setState(State.IDLE, "")
        }

        try {
            val v = packageManager.getPackageInfo(packageName, 0).versionName ?: ""
            findViewById<TextView>(R.id.tvVersion).text = "v$v"
        } catch (e: Exception) {
            // l'etichetta della versione è solo informativa
        }

        deleteShareDir() // eventuali residui di una sessione precedente
        loadModel()
    }

    override fun onStop() {
        super.onStop()
        // In background Android silenzia il microfono: meglio chiudere subito con quello che c'è.
        if (state == State.RECORDING) {
            extraNote = "Registrazione interrotta: l'app è andata in secondo piano. "
            stopRecording()
        }
    }

    @Deprecated("API del framework, sufficiente per questa app")
    override fun onBackPressed() {
        // Con un testo in anteprima, "Indietro" per sbaglio farebbe perdere le correzioni.
        if (state == State.READY && System.currentTimeMillis() - lastBack > 2000) {
            lastBack = System.currentTimeMillis()
            Toast.makeText(this, "Il testo non salvato andrà perso: premi di nuovo Indietro per uscire", Toast.LENGTH_LONG).show()
            return
        }
        super.onBackPressed()
    }

    override fun onDestroy() {
        state = State.IDLE // ignora eventuali risultati in arrivo
        releaseSpeech()
        deleteShareDir()
        try {
            model?.close()
        } catch (e: Exception) {
            // niente da fare in chiusura
        }
        model = null
        super.onDestroy()
    }

    // ── modello vocale ───────────────────────────────────────────────────────

    private fun loadModel() {
        setState(State.LOADING, "Carico il modello vocale…")
        Thread {
            try {
                val dir = prepareModelDir()
                LibVosk.setLogLevel(LogLevel.WARNINGS)
                val m = Model(dir.absolutePath)
                runOnUiThread {
                    model = m
                    setState(State.IDLE, "Pronto")
                }
            } catch (e: Throwable) {
                runOnUiThread { setState(State.ERROR, "Modello non caricato: ${e.message}") }
            }
        }.start()
    }

    /** Alla prima apertura copia il modello dagli asset nella memoria privata dell'app (poi lo riusa). */
    private fun prepareModelDir(): File {
        val target = File(filesDir, "model")
        val ok = File(filesDir, "model.ok")
        if (ok.exists() && target.isDirectory) return target
        if (assets.list(MODEL_ASSET_DIR).isNullOrEmpty()) {
            throw IllegalStateException("modello assente nell'app (assets/$MODEL_ASSET_DIR)")
        }
        target.deleteRecursively()
        copyAssets(MODEL_ASSET_DIR, target)
        ok.writeText("1")
        return target
    }

    private fun copyAssets(src: String, dst: File) {
        val names = assets.list(src) ?: emptyArray()
        if (names.isEmpty()) { // è un file
            dst.parentFile?.mkdirs()
            assets.open(src).use { input -> FileOutputStream(dst).use { out -> input.copyTo(out) } }
        } else {
            dst.mkdirs()
            for (n in names) copyAssets("$src/$n", File(dst, n))
        }
    }

    // ── registrazione ────────────────────────────────────────────────────────

    private fun startRecording() {
        val m = model
        if (m == null) {
            loadModel()
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQ_AUDIO)
            return
        }
        wipeAll()
        extraNote = ""
        try {
            val rec = Recognizer(m, SAMPLE_RATE)
            recognizer = rec
            val svc = SpeechService(rec, SAMPLE_RATE)
            speech = svc
            if (!svc.startListening(this)) throw IllegalStateException("il microfono non parte")
        } catch (e: Exception) {
            releaseSpeech()
            setState(State.ERROR, "Microfono non disponibile: ${e.message}")
            return
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        startedAt = System.currentTimeMillis()
        setState(State.RECORDING, "00:00")
        main.postDelayed(ticker, 500)
    }

    private fun stopRecording() {
        if (state != State.RECORDING) return
        setState(State.PROCESSING, "Elaboro…")
        val accepted = try {
            speech?.stop() ?: false // il risultato finale arriva in onFinalResult
        } catch (e: Exception) {
            false
        }
        if (!accepted) finishRecording()
    }

    private fun finishRecording() {
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        releaseSpeech()
        val elapsed = (System.currentTimeMillis() - startedAt) / 1000
        if (elapsed < MIN_SECONDS) {
            segments.clear()
            setState(State.ERROR, "Registrazione troppo breve.")
            return
        }
        if (segments.isEmpty()) {
            setState(State.ERROR, "Non ho sentito parlato. Controlla il microfono e riprova.")
            return
        }
        try {
            val parsed = SessionParser.parse(segments)
            val draft = SessionParser.draftBlocks(parsed, segments)
            val note = SessionParser.describe(parsed)
            rawText = segments.joinToString("\n") // per il controllo "Mostra trascrizione grezza"
            segments.clear() // dal testo grezzo in poi resta solo l'anteprima modificabile
            buildPreview(draft)
            setState(State.READY, "Controlla il testo e correggi se serve", extraNote + note)
        } catch (e: Exception) {
            setState(State.ERROR, "Errore nella preparazione del testo: ${e.message}")
        }
    }

    private fun releaseSpeech() {
        main.removeCallbacks(ticker)
        try {
            speech?.cancel() // se ha già finito non fa nulla e non genera altri risultati
            speech?.shutdown()
        } catch (e: Exception) {
            // già fermo
        }
        try {
            recognizer?.close()
        } catch (e: Exception) {
            // già chiuso
        }
        speech = null
        recognizer = null
    }

    // ── callback di Vosk (arrivano sul thread principale) ───────────────────

    override fun onPartialResult(hypothesis: String?) {
        if (state != State.RECORDING) return
        val p = try {
            JSONObject(hypothesis ?: return).optString("partial", "")
        } catch (e: Exception) {
            ""
        }
        tvLive.text = if (p.length > 120) "…" + p.takeLast(120) else p
    }

    override fun onResult(hypothesis: String?) {
        if (state == State.RECORDING || state == State.PROCESSING) addText(hypothesis)
    }

    override fun onFinalResult(hypothesis: String?) {
        if (state != State.PROCESSING) return
        addText(hypothesis)
        finishRecording()
    }

    override fun onError(exception: Exception?) {
        if (state != State.RECORDING && state != State.PROCESSING) return
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        releaseSpeech()
        setState(State.ERROR, "Errore del microfono: ${exception?.message}")
    }

    override fun onTimeout() = Unit

    /** Un "risultato" di Vosk è un JSON {"text": "..."}: un segmento di parlato chiuso da una pausa. */
    private fun addText(json: String?) {
        val t = try {
            JSONObject(json ?: return).optString("text", "").trim()
        } catch (e: Exception) {
            ""
        }
        if (t.isNotEmpty()) segments.add(t)
    }

    // ── anteprima modificabile ───────────────────────────────────────────────

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    /** Un titolo e un riquadro di testo per sezione; una riga = un punto elenco (o un paragrafo). */
    private fun buildPreview(blocks: List<SessionParser.Block>) {
        llPreview.removeAllViews()
        editors.clear()
        val hintColor = Color.argb(150, Color.red(textColor), Color.green(textColor), Color.blue(textColor))
        for (b in blocks) {
            val title = TextView(this).apply {
                text = b.title.uppercase(Locale.ITALY) + (if (b.optional) " (facoltativa)" else "")
                setTextColor(textColor)
                textSize = 13f
                typeface = Typeface.DEFAULT_BOLD
                setPadding(0, dp(16), 0, dp(4))
            }
            val edit = EditText(this).apply {
                setText(b.lines.joinToString("\n"))
                hint = if (b.optional) "Facoltativa: lascia vuoto per ometterla" else "Da definire"
                setHintTextColor(hintColor)
                setTextColor(textColor)
                textSize = 15f
                inputType = InputType.TYPE_CLASS_TEXT or
                    InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                    InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
                gravity = Gravity.TOP or Gravity.START
                minLines = 2
                setPadding(dp(10), dp(8), dp(10), dp(8))
                background = GradientDrawable().apply {
                    setColor(Color.TRANSPARENT)
                    setStroke(dp(1), textColor)
                    cornerRadius = dp(8).toFloat()
                }
            }
            llPreview.addView(title)
            llPreview.addView(edit)
            editors.add(Editor(b, edit))
        }
    }

    /** Genera il PDF dal testo che c'è ora nei riquadri (quindi con le tue correzioni). */
    private fun renderPdf(): ByteArray {
        val edited = editors.map {
            SessionParser.Block(it.block.title, it.block.bullets, it.edit.text.toString().split("\n"), it.block.optional)
        }
        val now = Date()
        pdfName = "riepilogo_" + SimpleDateFormat("ddMMyyyy_HHmm", Locale.ITALY).format(now) + ".pdf"
        return PdfBuilder.build(
            this,
            SessionParser.finalBlocks(edited),
            SimpleDateFormat("dd/MM/yyyy", Locale.ITALY).format(now),
            SimpleDateFormat("dd/MM/yyyy 'alle' HH:mm", Locale.ITALY).format(now)
        )
    }

    // ── permessi, salvataggio, condivisione ─────────────────────────────────

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_AUDIO) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                setState(State.IDLE, "Permesso concesso: premi REGISTRA")
            } else {
                setState(State.ERROR, "Serve il permesso del microfono (Impostazioni → App → Brief rapido per coach → Permessi).")
            }
        }
    }

    private fun savePdf() {
        if (editors.isEmpty()) return
        try {
            pdf = renderPdf()
        } catch (e: Exception) {
            tvNote.text = "Errore nella creazione del PDF: ${e.message}"
            return
        }
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
            .addCategory(Intent.CATEGORY_OPENABLE)
            .setType("application/pdf")
            .putExtra(Intent.EXTRA_TITLE, pdfName)
        startActivityForResult(i, REQ_SAVE)
    }

    @Deprecated("API del framework, sufficiente per questa app")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_SAVE || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        val bytes = pdf ?: return
        try {
            contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
            wipeAll() // una tantum: salvato, testo e PDF in memoria vengono cancellati
            setState(State.IDLE, "Salvato. Copia cancellata dalla memoria.")
        } catch (e: Exception) {
            tvNote.text = "Salvataggio non riuscito: ${e.message}"
        }
    }

    private fun sharePdf() {
        if (editors.isEmpty()) return
        try {
            val bytes = renderPdf()
            val dir = File(cacheDir, "share").apply { mkdirs() }
            val f = File(dir, pdfName)
            f.writeBytes(bytes)
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
            val send = Intent(Intent.ACTION_SEND)
                .setType("application/pdf")
                .putExtra(Intent.EXTRA_STREAM, uri)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(send, "Condividi il brief"))
        } catch (e: Exception) {
            tvNote.text = "Condivisione non riuscita: ${e.message}"
        }
    }

    /** Mostra o nasconde ciò che Vosk ha sentito davvero, senza marker né correzioni (utile per capire gli errori). */
    private fun toggleRaw() {
        if (tvRaw.visibility == View.VISIBLE) {
            tvRaw.visibility = View.GONE
            btnRaw.text = "Mostra trascrizione grezza"
        } else {
            tvRaw.text = rawText
            tvRaw.visibility = View.VISIBLE
            btnRaw.text = "Nascondi trascrizione grezza"
        }
    }

    // ── pulizia e interfaccia ────────────────────────────────────────────────

    private fun wipeAll() {
        segments.clear()
        rawText = ""
        tvRaw.text = ""
        editors.clear()
        llPreview.removeAllViews()
        pdf = null
        deleteShareDir()
    }

    private fun deleteShareDir() {
        File(cacheDir, "share").deleteRecursively()
    }

    private fun setState(s: State, status: String, note: String = "") {
        state = s
        tvStatus.text = status
        tvNote.text = note
        if (s != State.RECORDING) tvLive.text = ""

        val ready = s == State.READY
        btnMain.visibility = if (ready) View.GONE else View.VISIBLE
        llPreview.visibility = if (ready) View.VISIBLE else View.GONE
        btnSave.visibility = if (ready) View.VISIBLE else View.GONE
        btnShare.visibility = if (ready) View.VISIBLE else View.GONE
        btnAgain.visibility = if (ready) View.VISIBLE else View.GONE
        btnRaw.visibility = if (ready) View.VISIBLE else View.GONE
        if (!ready) {
            tvRaw.visibility = View.GONE
            btnRaw.text = "Mostra trascrizione grezza"
        }

        btnMain.isEnabled = s == State.IDLE || s == State.RECORDING || s == State.ERROR
        btnMain.alpha = if (btnMain.isEnabled) 1f else 0.5f
        btnMain.text = when (s) {
            State.RECORDING -> "⏹ STOP"
            State.LOADING -> "Carico…"
            State.PROCESSING -> "Elaboro…"
            else -> "⏺ REGISTRA"
        }
    }
}
