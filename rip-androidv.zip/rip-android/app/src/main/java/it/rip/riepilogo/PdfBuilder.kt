package it.rip.riepilogo

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import java.io.ByteArrayOutputStream
import java.util.Locale

/** Genera il PDF in memoria con l'API standard di Android (nessuna libreria esterna). */
object PdfBuilder {
    private const val PAGE_W = 595 // A4 a 72 dpi
    private const val PAGE_H = 842
    private const val MARGIN = 56f

    private val pageBg = Color.parseColor("#EFE8D8")
    private val textBrown = Color.parseColor("#8E6D3F")
    private val mutedBrown = Color.argb(170, 142, 109, 63)
    private val ruleBrown = Color.argb(120, 142, 109, 63)

    private fun geologica(context: Context, bold: Boolean = false): Typeface {
        val path = "fonts/geologica.ttf"
        return if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            Typeface.Builder(context.assets, path)
                .setFontVariationSettings(if (bold) "'wght' 700" else "'wght' 400")
                .build()
        } else {
            val base = Typeface.createFromAsset(context.assets, path)
            if (bold) Typeface.create(base, Typeface.BOLD) else base
        } ?: throw IllegalStateException("Geologica non presente negli asset: verifica la compilazione")
    }

    private fun paint(size: Float, typeface: Typeface, c: Int): TextPaint =
        TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = size
            this.typeface = typeface
            color = c
        }

    private fun layout(text: String, p: TextPaint, width: Int, align: Layout.Alignment): StaticLayout =
        StaticLayout.Builder.obtain(text, 0, text.length, p, width)
            .setAlignment(align)
            .setLineSpacing(0f, 1.18f)
            .build()

    /** Tiene traccia di pagina corrente e posizione verticale; va a capo pagina quando serve. */
    private class Writer(
        val doc: PdfDocument,
        val bgColor: Int,
        val mark: Bitmap?
    ) {
        var page: PdfDocument.Page? = null
        var canvas: Canvas? = null
        var pageNo = 0
        var y = MARGIN

        fun newPage() {
            page?.let { doc.finishPage(it) }
            pageNo++
            val pg = doc.startPage(PdfDocument.PageInfo.Builder(PAGE_W, PAGE_H, pageNo).create())
            page = pg
            canvas = pg.canvas
            pg.canvas.drawColor(bgColor)
            drawMark(pg.canvas)
            y = MARGIN
        }

        private fun drawMark(c: Canvas) {
            val logo = mark ?: return
            val targetH = 22f
            val scale = targetH / logo.height.toFloat()
            val targetW = logo.width * scale
            val x = PAGE_W - MARGIN - targetW
            val y = PAGE_H - MARGIN + 4f - targetH
            val dst = android.graphics.RectF(x, y, x + targetW, y + targetH)
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { alpha = 150 }
            c.drawBitmap(logo, null, dst, p)
        }

        fun ensure(h: Float) {
            if (page == null || y + h > PAGE_H - MARGIN - 18f) newPage()
        }

        fun draw(l: StaticLayout, x: Float, advance: Boolean = true) {
            ensure(l.height.toFloat())
            val c = canvas!!
            c.save()
            c.translate(x, y)
            l.draw(c)
            c.restore()
            if (advance) y += l.height
        }

        fun space(h: Float) {
            y += h
        }

        fun rule(p: Paint) {
            ensure(8f)
            canvas!!.drawLine(MARGIN, y, PAGE_W - MARGIN, y, p)
            y += 1f
        }

        fun finish() {
            page?.let { doc.finishPage(it) }
            page = null
        }
    }

    fun build(context: Context, blocks: List<SessionParser.Block>, date: String, generatedAt: String): ByteArray {
        val doc = PdfDocument()
        val mark = BitmapFactory.decodeResource(context.resources, R.drawable.the_coach_kit_mark)
        val w = Writer(doc, pageBg, mark)
        val width = (PAGE_W - 2 * MARGIN).toInt()
        val left = Layout.Alignment.ALIGN_NORMAL

        val titleP = paint(20f, geologica(context, bold = true), textBrown)
        val metaP = paint(11f, geologica(context, bold = false), mutedBrown)
        val headP = paint(12f, geologica(context, bold = true), textBrown)
        val bodyP = paint(11f, geologica(context, bold = false), textBrown)
        val footP = paint(9f, geologica(context, bold = false), mutedBrown)
        val rulePaint = Paint().apply {
            color = ruleBrown
            strokeWidth = 1f
        }

        w.newPage()
        w.draw(layout("Riepilogo Sessione di Coaching", titleP, width, left), MARGIN)
        w.space(4f)
        w.draw(layout("Data: $date", metaP, width, left), MARGIN)
        w.space(8f)
        w.rule(rulePaint)
        w.space(18f)

        for (b in blocks) {
            val head = layout(b.title.uppercase(Locale.ITALY), headP, width, left)
            w.ensure(head.height + 48f) // niente titolo orfano a fondo pagina
            w.draw(head, MARGIN)
            w.space(6f)
            for (line in b.lines) {
                if (b.bullets) {
                    val l = layout(line, bodyP, width - 22, left)
                    w.ensure(l.height.toFloat())
                    w.draw(layout("•", bodyP, 14, left), MARGIN + 8f, advance = false)
                    w.draw(l, MARGIN + 22f)
                    w.space(5f)
                } else {
                    w.draw(layout(line, bodyP, width, left), MARGIN)
                    w.space(5f)
                }
            }
            w.space(12f)
        }

        w.space(4f)
        w.rule(rulePaint)
        w.space(8f)
        w.draw(layout("Generato il $generatedAt", footP, width, Layout.Alignment.ALIGN_CENTER), MARGIN)
        w.finish()

        val out = ByteArrayOutputStream()
        doc.writeTo(out)
        doc.close()
        return out.toByteArray()
    }
}
